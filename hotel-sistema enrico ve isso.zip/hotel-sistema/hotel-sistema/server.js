const express    = require('express');
const session    = require('express-session');
const flash      = require('connect-flash');
const path       = require('path');
const bcrypt     = require('bcryptjs');
const { MongoClient, ObjectId } = require('mongodb');

const app  = express();
const PORT = 3000;

// ══════════════════════════════════════════════════════════════
// BANCO DE DADOS
// ══════════════════════════════════════════════════════════════
const MONGO_URI = 'mongodb://localhost:27017'; // ✏ cole sua string do Atlas aqui
const DB_NAME   = 'hotel_db';
const client    = new MongoClient(MONGO_URI);
let db;

async function conectar() {
  await client.connect();
  db = client.db(DB_NAME);
  console.log(`✅ Banco "${DB_NAME}" conectado!`);
}

function getUsuarios() { return db.collection('usuarios'); }
function getQuartos()  { return db.collection('quartos');  }

// ══════════════════════════════════════════════════════════════
// CONFIGURAÇÃO DO SERVIDOR
// ══════════════════════════════════════════════════════════════
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'hotel_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 }
}));
app.use(flash());

// ══════════════════════════════════════════════════════════════
// MIDDLEWARE — verifica se o usuário está logado
// ══════════════════════════════════════════════════════════════
function autenticado(req, res, next) {
  if (req.session && req.session.usuario) return next();
  req.flash('erro', 'Faça login para acessar.');
  res.redirect('/login');
}

// ══════════════════════════════════════════════════════════════
// AUTH — cadastro, login, logout
// ══════════════════════════════════════════════════════════════
app.get('/cadastro', (req, res) => {
  res.render('cadastro', { erro: req.flash('erro'), sucesso: req.flash('sucesso') });
});

app.post('/cadastro', async (req, res) => {
  const { nome, login, senha } = req.body;
  try {
    const usuarios = getUsuarios();
    const existe = await usuarios.findOne({ login });
    if (existe) {
      req.flash('erro', 'Login já cadastrado. Escolha outro.');
      return res.redirect('/cadastro');
    }
    const hash = await bcrypt.hash(senha, 10);
    await usuarios.insertOne({ nome, login, senha: hash, criadoEm: new Date() });
    req.flash('sucesso', 'Cadastro realizado! Faça login.');
    res.redirect('/login');
  } catch (err) {
    req.flash('erro', 'Erro: ' + err.message);
    res.redirect('/cadastro');
  }
});

app.get('/login', (req, res) => {
  res.render('login', { erro: req.flash('erro') });
});

app.post('/login', async (req, res) => {
  const { login, senha } = req.body;
  try {
    const usuarios = getUsuarios();
    const usuario  = await usuarios.findOne({ login });
    if (!usuario || !await bcrypt.compare(senha, usuario.senha)) {
      req.flash('erro', 'Login ou senha incorretos.');
      return res.redirect('/login');
    }
    req.session.usuario = { id: usuario._id.toString(), nome: usuario.nome, login: usuario.login };
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro: ' + err.message);
    res.redirect('/login');
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// ══════════════════════════════════════════════════════════════
// QUARTOS — CRUD + reservar
// ══════════════════════════════════════════════════════════════

// READ — listagem pública
app.get('/quartos', async (req, res) => {
  try {
    const lista = await getQuartos().find().sort({ numero: 1 }).toArray();
    res.render('quartos-lista', { quartos: lista, usuario: req.session.usuario || null });
  } catch (err) { res.status(500).send(err.message); }
});

// READ — painel de gerência
app.get('/quartos/gerencia', autenticado, async (req, res) => {
  try {
    const lista = await getQuartos().find().sort({ numero: 1 }).toArray();
    res.render('quartos-gerencia', {
      quartos: lista,
      usuario: req.session.usuario,
      erro: req.flash('erro'),
      sucesso: req.flash('sucesso')
    });
  } catch (err) { res.status(500).send(err.message); }
});

// CREATE
app.post('/quartos', autenticado, async (req, res) => {
  const { numero, tipo, preco, capacidade, qtde_disponivel } = req.body;
  try {
    await getQuartos().insertOne({
      numero, tipo,
      preco: Number(preco),
      capacidade: Number(capacidade),
      qtde_disponivel: Number(qtde_disponivel),
      criadoEm: new Date()
    });
    req.flash('sucesso', `Quarto ${numero} cadastrado com sucesso!`);
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

// UPDATE
app.post('/quartos/:id/atualizar', autenticado, async (req, res) => {
  const { numero, tipo, preco, capacidade, qtde_disponivel } = req.body;
  try {
    await getQuartos().updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { numero, tipo, preco: Number(preco), capacidade: Number(capacidade), qtde_disponivel: Number(qtde_disponivel), atualizadoEm: new Date() } }
    );
    req.flash('sucesso', 'Quarto atualizado com sucesso!');
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

// DELETE
app.post('/quartos/:id/remover', autenticado, async (req, res) => {
  try {
    const quarto = await getQuartos().findOne({ _id: new ObjectId(req.params.id) });
    if (!quarto) { req.flash('erro', 'Quarto não encontrado.'); return res.redirect('/quartos/gerencia'); }
    await getQuartos().deleteOne({ _id: new ObjectId(req.params.id) });
    req.flash('sucesso', `Quarto ${quarto.numero} removido.`);
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

// RESERVAR
app.post('/quartos/:id/reservar', autenticado, async (req, res) => {
  try {
    const quarto = await getQuartos().findOne({ _id: new ObjectId(req.params.id) });
    if (!quarto) { req.flash('erro', 'Quarto não encontrado.'); return res.redirect('/quartos/gerencia'); }
    if (quarto.qtde_disponivel <= 0) {
      req.flash('erro', `Quarto ${quarto.numero} está LOTADO!`);
      return res.redirect('/quartos/gerencia');
    }
    await getQuartos().updateOne(
      { _id: new ObjectId(req.params.id) },
      { $inc: { qtde_disponivel: -1 } }
    );
    req.flash('sucesso', `Quarto ${quarto.numero} reservado! Restam ${quarto.qtde_disponivel - 1} vaga(s).`);
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

// ══════════════════════════════════════════════════════════════
// INICIAR SERVIDOR
// ══════════════════════════════════════════════════════════════
async function iniciar() {
  try {
    await conectar();
    app.listen(PORT, () => console.log(`🚀 Servidor em http://localhost:${PORT}`));
  } catch (err) {
    console.error('❌ Erro:', err.message);
    process.exit(1);
  }
}
iniciar();