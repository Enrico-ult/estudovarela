const express = require('express');
const session = require('express-session');
const flash   = require('connect-flash');
const path    = require('path');
const { conectar } = require('./db');

const app  = express();
const PORT = 80;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'hotel_secret_2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 }
}));
app.use(flash());

const authRoutes    = require('./routes/auth');
const quartosRoutes = require('./routes/quartos');

app.get('/', (req, res) => res.redirect('/projects'));

app.get('/projects', (req, res) => {
  res.render('projects', { usuario: req.session.usuario || null });
});

app.use('/', authRoutes);
app.use('/quartos', quartosRoutes);

async function iniciar() {
  try {
    await conectar();
    app.listen(PORT, () => {
      console.log(`🏨 Hotel rodando em http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('❌ Erro ao conectar ao MongoDB:', err.message);
    process.exit(1);
  }
}

iniciar();
