const express = require('express');
const router  = express.Router();
const { getQuartos, ObjectId } = require('../db');

function autenticado(req, res, next) {
  if (req.session && req.session.usuario) return next();
  req.flash('erro', 'Faça login para acessar esta página.');
  res.redirect('/login');
}

// READ — listagem pública
router.get('/', async (req, res) => {
  try {
    const lista = await getQuartos().find().sort({ tipo: 1, numero: 1 }).toArray();
    res.render('quartos-lista', { quartos: lista, usuario: req.session.usuario || null });
  } catch (err) {
    res.status(500).send('Erro: ' + err.message);
  }
});

// READ — painel de gerência
router.get('/gerencia', autenticado, async (req, res) => {
  try {
    const lista = await getQuartos().find().sort({ numero: 1 }).toArray();
    res.render('quartos-gerencia', {
      quartos: lista,
      usuario: req.session.usuario,
      erro:    req.flash('erro'),
      sucesso: req.flash('sucesso')
    });
  } catch (err) {
    res.status(500).send('Erro: ' + err.message);
  }
});

// CREATE — cadastrar novo quarto
router.post('/', autenticado, async (req, res) => {
  const { numero, tipo, preco, capacidade, qtde_disponivel } = req.body;
  try {
    await getQuartos().insertOne({
      numero,
      tipo,
      preco:           Number(preco),
      capacidade:      Number(capacidade),
      qtde_disponivel: Number(qtde_disponivel),
      criadoEm:        new Date()
    });
    req.flash('sucesso', `Quarto ${numero} (${tipo}) cadastrado com sucesso!`);
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro ao cadastrar: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

// UPDATE — atualizar quarto
router.post('/:id/atualizar', autenticado, async (req, res) => {
  const { numero, tipo, preco, capacidade, qtde_disponivel } = req.body;
  try {
    await getQuartos().updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: {
          numero,
          tipo,
          preco:           Number(preco),
          capacidade:      Number(capacidade),
          qtde_disponivel: Number(qtde_disponivel),
          atualizadoEm:    new Date()
        }
      }
    );
    req.flash('sucesso', 'Quarto atualizado com sucesso!');
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro ao atualizar: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

// DELETE — remover quarto
router.post('/:id/remover', autenticado, async (req, res) => {
  try {
    const quarto = await getQuartos().findOne({ _id: new ObjectId(req.params.id) });
    if (!quarto) {
      req.flash('erro', 'Quarto não encontrado.');
      return res.redirect('/quartos/gerencia');
    }
    await getQuartos().deleteOne({ _id: new ObjectId(req.params.id) });
    req.flash('sucesso', `Quarto ${quarto.numero} removido.`);
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro ao remover: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

// UPDATE — reservar quarto (decrementa disponibilidade)
router.post('/:id/reservar', autenticado, async (req, res) => {
  try {
    const quarto = await getQuartos().findOne({ _id: new ObjectId(req.params.id) });
    if (!quarto) {
      req.flash('erro', 'Quarto não encontrado.');
      return res.redirect('/quartos/gerencia');
    }
    if (quarto.qtde_disponivel <= 0) {
      req.flash('erro', `Quarto ${quarto.numero} (${quarto.tipo}) está ESGOTADO!`);
      return res.redirect('/quartos/gerencia');
    }
    await getQuartos().updateOne(
      { _id: new ObjectId(req.params.id) },
      { $inc: { qtde_disponivel: -1 } }
    );
    const restam = quarto.qtde_disponivel - 1;
    req.flash('sucesso', `Reserva registrada! Restam ${restam} unidade(s) do quarto ${quarto.numero}.`);
    res.redirect('/quartos/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro ao reservar: ' + err.message);
    res.redirect('/quartos/gerencia');
  }
});

module.exports = router;
