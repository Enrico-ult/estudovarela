const express = require('express');
const router  = express.Router();
const { getItens, ObjectId } = require('../db');

// ══════════════════════════════════════════════════════════════════
// ✏ GUIA DE PERSONALIZAÇÃO DESTE ARQUIVO
// ══════════════════════════════════════════════════════════════════
//
// 1. Renomeie este arquivo de 'itens.js' para o nome da sua entidade.
//    Exemplo: produtos.js, livros.js, pacientes.js
//
// 2. Em cada rota, os campos que vêm do formulário (req.body) devem
//    bater com os name="" dos inputs no arquivo EJS correspondente.
//    Veja os comentários "✏ CAMPOS" em cada rota abaixo.
//
// 3. Substitua todos os 'getItens()' pela sua função do db.js.
//    Exemplo: getItens() → getProdutos()
//
// 4. Troque o texto das flash messages pelo nome da sua entidade.
//    Exemplo: 'Item cadastrado' → 'Produto cadastrado'
//
// 5. Os redirecionamentos res.redirect('/itens/gerencia') devem
//    bater com a rota registrada no server.js.
// ══════════════════════════════════════════════════════════════════

function autenticado(req, res, next) {
  if (req.session && req.session.usuario) return next();
  req.flash('erro', 'Faça login para acessar esta página.');
  res.redirect('/login');
}

// ──────────────────────────────────────────────────────────────────
// READ — listagem pública
// ──────────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    // ✏ Mude o campo de ordenação para o campo principal da sua entidade.
    // Exemplo: { nome: 1 } / { titulo: 1 } / { numero: 1 }
    const lista = await getItens().find().sort({ nome: 1 }).toArray();

    // ✏ Mude 'itens-lista' para o nome do seu arquivo EJS de listagem
    res.render('itens-lista', { itens: lista, usuario: req.session.usuario || null });
  } catch (err) {
    res.status(500).send('Erro: ' + err.message);
  }
});

// ──────────────────────────────────────────────────────────────────
// READ — painel de gerência (requer login)
// ──────────────────────────────────────────────────────────────────
router.get('/gerencia', autenticado, async (req, res) => {
  try {
    const lista = await getItens().find().sort({ nome: 1 }).toArray(); // ✏ campo de ordenação

    // ✏ Mude 'itens-gerencia' para o nome do seu arquivo EJS de gerência
    res.render('itens-gerencia', {
      itens:   lista,
      usuario: req.session.usuario,
      erro:    req.flash('erro'),
      sucesso: req.flash('sucesso')
    });
  } catch (err) {
    res.status(500).send('Erro: ' + err.message);
  }
});

// ──────────────────────────────────────────────────────────────────
// CREATE — cadastrar novo item
// ──────────────────────────────────────────────────────────────────
router.post('/', autenticado, async (req, res) => {

  // ✏ CAMPOS — extraia aqui os campos do seu formulário
  // Os nomes devem bater com os name="" dos inputs no EJS
  // ----------------------------------------------------------
  // Exemplo para produtos:
  //   const { nome, preco, categoria, qtde_disponivel } = req.body;
  //
  // Exemplo para livros:
  //   const { titulo, autor, ano, isbn, qtde_disponivel } = req.body;
  //
  // Exemplo para pacientes:
  //   const { nome, cpf, telefone, convenio } = req.body;
  // ----------------------------------------------------------
  const { nome, descricao, quantidade } = req.body; // ✏ MUDE AQUI

  try {
    await getItens().insertOne({
      // ✏ CAMPOS — salve aqui os mesmos campos acima
      // Campos numéricos precisam de Number(), ex: preco: Number(preco)
      // Campos de texto podem ser salvos direto, ex: nome, titulo, cpf
      // ----------------------------------------------------------
      nome,
      descricao,
      quantidade:      Number(quantidade), // ✏ MUDE AQUI
      qtde_disponivel: Number(quantidade), // ✏ se tiver controle de estoque, ajuste
      criadoEm:        new Date()
    });

    req.flash('sucesso', `Item "${nome}" cadastrado!`); // ✏ ajuste o texto
    res.redirect('/itens/gerencia'); // ✏ ajuste a rota
  } catch (err) {
    req.flash('erro', 'Erro ao cadastrar: ' + err.message);
    res.redirect('/itens/gerencia'); // ✏ ajuste a rota
  }
});

// ──────────────────────────────────────────────────────────────────
// UPDATE — atualizar item
// ──────────────────────────────────────────────────────────────────
router.post('/:id/atualizar', autenticado, async (req, res) => {

  // ✏ Mesmos campos do CREATE
  const { nome, descricao, quantidade } = req.body; // ✏ MUDE AQUI

  try {
    await getItens().updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: {
          // ✏ Mesmos campos acima
          nome,
          descricao,
          quantidade:   Number(quantidade), // ✏ MUDE AQUI
          atualizadoEm: new Date()
        }
      }
    );
    req.flash('sucesso', 'Item atualizado com sucesso!'); // ✏ ajuste o texto
    res.redirect('/itens/gerencia'); // ✏ ajuste a rota
  } catch (err) {
    req.flash('erro', 'Erro ao atualizar: ' + err.message);
    res.redirect('/itens/gerencia');
  }
});

// ──────────────────────────────────────────────────────────────────
// DELETE — remover item
// ──────────────────────────────────────────────────────────────────
router.post('/:id/remover', autenticado, async (req, res) => {
  try {
    // ✏ Mude 'item.nome' para o campo principal da sua entidade
    // para exibir na mensagem de confirmação.
    // Exemplo: item.titulo / item.numero / item.cpf
    const item = await getItens().findOne({ _id: new ObjectId(req.params.id) });

    if (!item) {
      req.flash('erro', 'Item não encontrado.');
      return res.redirect('/itens/gerencia'); // ✏ ajuste a rota
    }

    await getItens().deleteOne({ _id: new ObjectId(req.params.id) });

    req.flash('sucesso', `"${item.nome}" removido.`); // ✏ ajuste o campo e texto
    res.redirect('/itens/gerencia'); // ✏ ajuste a rota
  } catch (err) {
    req.flash('erro', 'Erro ao remover: ' + err.message);
    res.redirect('/itens/gerencia');
  }
});

// ──────────────────────────────────────────────────────────────────
// UPDATE ESPECIAL — ação personalizada (ex: vender, reservar, emprestar)
// Decrementa qtde_disponivel em 1
// ──────────────────────────────────────────────────────────────────
// ✏ Renomeie esta rota de '/itens/:id/usar' para a ação do seu tema:
//   /carros/:id/vender
//   /quartos/:id/reservar
//   /livros/:id/emprestar
router.post('/:id/usar', autenticado, async (req, res) => {
  try {
    const item = await getItens().findOne({ _id: new ObjectId(req.params.id) });

    if (!item) {
      req.flash('erro', 'Item não encontrado.');
      return res.redirect('/itens/gerencia');
    }

    if (item.qtde_disponivel <= 0) {
      // ✏ Ajuste a mensagem para o seu contexto
      // Exemplo: 'já está ESGOTADO!' / 'sem estoque' / 'sem vagas'
      req.flash('erro', `"${item.nome}" está ESGOTADO!`);
      return res.redirect('/itens/gerencia');
    }

    await getItens().updateOne(
      { _id: new ObjectId(req.params.id) },
      { $inc: { qtde_disponivel: -1 } }
    );

    const restam = item.qtde_disponivel - 1;
    // ✏ Ajuste o texto da mensagem de sucesso
    req.flash('sucesso', `Ação registrada! Restam ${restam} unidade(s) de "${item.nome}".`);
    res.redirect('/itens/gerencia');
  } catch (err) {
    req.flash('erro', 'Erro: ' + err.message);
    res.redirect('/itens/gerencia');
  }
});

module.exports = router;
