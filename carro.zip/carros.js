const express = require('express');
const router  = express.Router();

// ObjectId: classe do MongoDB para converter string de ID para o tipo correto
// IMPORTANTE: o MongoDB armazena _id como ObjectId, não como string simples
// Se você buscar por { _id: '507f1f77...' } não vai encontrar nada
// Precisa converter: { _id: new ObjectId('507f1f77...') }
const { getCarros, ObjectId } = require('../db');


// ─────────────────────────────────────────────────────────────
// MIDDLEWARE DE AUTENTICAÇÃO
// ─────────────────────────────────────────────────────────────
function autenticado(req, res, next) {
  if (req.session && req.session.usuario) return next();
  req.flash('erro', 'Faça login para acessar esta página.');
  res.redirect('/login');
}


// ─────────────────────────────────────────────────────────────
// GET /carros — READ: listagem pública
// ─────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const carros = getCarros();

    // Com Mongoose: await Carro.find().sort({ marca: 1 })
    // Com MongoDB:  await collection.find().sort({ marca: 1 }).toArray()
    // DIFERENÇA: o MongoDB retorna um Cursor (ponteiro), não um array diretamente
    // precisamos chamar .toArray() para converter em array utilizável
    const lista = await carros.find().sort({ marca: 1, modelo: 1 }).toArray();

    res.render('carros-lista', {
      carros: lista,
      usuario: req.session.usuario || null
    });

  } catch (err) {
    res.status(500).send('Erro ao buscar carros: ' + err.message);
  }
});


// ─────────────────────────────────────────────────────────────
// GET /carros/gerencia — READ: painel (requer login)
// ─────────────────────────────────────────────────────────────
router.get('/gerencia', autenticado, async (req, res) => {
  try {
    const carros = getCarros();
    const lista  = await carros.find().sort({ marca: 1 }).toArray();

    res.render('carros-gerencia', {
      carros:  lista,
      usuario: req.session.usuario,
      erro:    req.flash('erro'),
      sucesso: req.flash('sucesso')
    });

  } catch (err) {
    res.status(500).send('Erro ao buscar carros: ' + err.message);
  }
});


// ─────────────────────────────────────────────────────────────
// POST /carros — CREATE: cadastra novo carro
// ─────────────────────────────────────────────────────────────
router.post('/', autenticado, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body;

  try {
    const carros = getCarros();

    // Com Mongoose: await Carro.create({ marca, modelo, ... })
    // Com MongoDB:  await collection.insertOne({ ... })
    // Sem Mongoose não há validação automática de schema —
    // os dados são inseridos como você passar, sem verificações
    await carros.insertOne({
      marca,
      modelo,
      ano:             Number(ano),            // converte string → número manualmente
      qtde_disponivel: Number(qtde_disponivel),
      criadoEm:        new Date()              // timestamp manual (Mongoose fazia isso automático)
    });

    req.flash('sucesso', `Carro ${marca} ${modelo} cadastrado com sucesso!`);
    res.redirect('/carros/gerencia');

  } catch (err) {
    req.flash('erro', 'Erro ao cadastrar carro: ' + err.message);
    res.redirect('/carros/gerencia');
  }
});


// ─────────────────────────────────────────────────────────────
// POST /carros/:id/atualizar — UPDATE: atualiza dados do carro
// ─────────────────────────────────────────────────────────────
router.post('/:id/atualizar', autenticado, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body;

  try {
    const carros = getCarros();

    // Com Mongoose: await Carro.findByIdAndUpdate(id, { marca, modelo, ... })
    // Com MongoDB:  await collection.updateOne(filtro, { $set: { campos } })
    //
    // DIFERENÇA IMPORTANTE:
    // - O filtro usa { _id: new ObjectId(id) } — precisa converter a string para ObjectId
    // - O segundo argumento usa o operador $set: { ... }
    //   $set diz "atualize apenas esses campos" — sem ele, o documento inteiro seria substituído
    await carros.updateOne(
      { _id: new ObjectId(req.params.id) },   // filtro: qual documento atualizar
      { $set: {                                // $set: quais campos mudar
          marca,
          modelo,
          ano:             Number(ano),
          qtde_disponivel: Number(qtde_disponivel),
          atualizadoEm:    new Date()          // timestamp de atualização manual
        }
      }
    );

    req.flash('sucesso', 'Carro atualizado com sucesso!');
    res.redirect('/carros/gerencia');

  } catch (err) {
    req.flash('erro', 'Erro ao atualizar carro: ' + err.message);
    res.redirect('/carros/gerencia');
  }
});


// ─────────────────────────────────────────────────────────────
// POST /carros/:id/remover — DELETE: remove carro
// ─────────────────────────────────────────────────────────────
router.post('/:id/remover', autenticado, async (req, res) => {
  try {
    const carros = getCarros();

    // Busca o carro antes de deletar para usar o nome na mensagem
    // Com Mongoose: await Carro.findByIdAndDelete(id) já retornava o documento
    // Com MongoDB: precisamos buscar e deletar em dois passos separados
    const carro = await carros.findOne({ _id: new ObjectId(req.params.id) });

    if (!carro) {
      req.flash('erro', 'Carro não encontrado.');
      return res.redirect('/carros/gerencia');
    }

    // Com Mongoose: await Carro.findByIdAndDelete(id)
    // Com MongoDB:  await collection.deleteOne({ _id: new ObjectId(id) })
    await carros.deleteOne({ _id: new ObjectId(req.params.id) });

    req.flash('sucesso', `Carro ${carro.marca} ${carro.modelo} removido.`);
    res.redirect('/carros/gerencia');

  } catch (err) {
    req.flash('erro', 'Erro ao remover carro: ' + err.message);
    res.redirect('/carros/gerencia');
  }
});


// ─────────────────────────────────────────────────────────────
// POST /carros/:id/vender — UPDATE: decrementa quantidade
// ─────────────────────────────────────────────────────────────
router.post('/:id/vender', autenticado, async (req, res) => {
  try {
    const carros = getCarros();

    // Busca o carro para verificar o estoque antes de vender
    const carro = await carros.findOne({ _id: new ObjectId(req.params.id) });

    if (!carro) {
      req.flash('erro', 'Carro não encontrado.');
      return res.redirect('/carros/gerencia');
    }

    if (carro.qtde_disponivel <= 0) {
      req.flash('erro', `${carro.marca} ${carro.modelo} já está ESGOTADO!`);
      return res.redirect('/carros/gerencia');
    }

    // Com Mongoose: carro.qtde_disponivel -= 1; await carro.save()
    // Com MongoDB: usamos o operador $inc para incrementar/decrementar diretamente
    // $inc: { campo: -1 } significa "subtraia 1 do campo"
    // Mais eficiente: faz tudo em uma única operação no banco
    await carros.updateOne(
      { _id: new ObjectId(req.params.id) },
      { $inc: { qtde_disponivel: -1 } } // $inc com valor negativo = decremento
    );

    const restam = carro.qtde_disponivel - 1; // calcula localmente para a mensagem
    req.flash('sucesso',
      `Venda registrada! Restam ${restam} unidade(s) de ${carro.marca} ${carro.modelo}.`
    );
    res.redirect('/carros/gerencia');

  } catch (err) {
    req.flash('erro', 'Erro ao registrar venda: ' + err.message);
    res.redirect('/carros/gerencia');
  }
});


module.exports = router;
