// Importa o MongoClient — classe principal do driver oficial do MongoDB
const { MongoClient, ObjectId } = require('mongodb');

// URI de conexão com o banco
// process.env.MONGO_URI: variável de ambiente (útil em produção)
// fallback: banco local na porta padrão 27017
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017';

// Nome do banco de dados que vamos usar
// O MongoDB cria automaticamente se não existir
const DB_NAME = 'carros_db';

// Cria uma instância do cliente — ainda não conecta, só configura
const client = new MongoClient(MONGO_URI);

// Variável que vai guardar a referência ao banco após conectar
let db;

// ─────────────────────────────────────────────────────────────
// Função de conexão — chamada uma vez ao iniciar o servidor
// ─────────────────────────────────────────────────────────────
async function conectar() {
  // client.connect() abre a conexão com o MongoDB
  await client.connect();

  // client.db() seleciona o banco de dados pelo nome
  // guarda na variável 'db' para reutilizar em todo o projeto
  db = client.db(DB_NAME);

  console.log('✅ MongoDB conectado com sucesso!');
}

// ─────────────────────────────────────────────────────────────
// Funções que retornam as coleções do banco
// Chamamos uma função em vez de acessar 'db' direto
// pois 'db' só existe depois de conectar()
// ─────────────────────────────────────────────────────────────

// Retorna a coleção 'usuarios'
function getUsuarios() {
  return db.collection('usuarios');
}

// Retorna a coleção 'carros'
function getCarros() {
  return db.collection('carros');
}

// ─────────────────────────────────────────────────────────────
// Exporta tudo que outros arquivos precisam usar
// ─────────────────────────────────────────────────────────────
module.exports = { conectar, getUsuarios, getCarros, ObjectId };
