const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcryptjs');

// Importa a função que retorna a coleção 'usuarios'
// Com Mongoose era: require('../models/Usuario') e usávamos Usuario.findOne()
// Agora pegamos a coleção diretamente e chamamos os métodos do MongoDB
const { getUsuarios } = require('../db');


// ─────────────────────────────────────────────────────────────
// GET /cadastro — exibe o formulário
// ─────────────────────────────────────────────────────────────
router.get('/cadastro', (req, res) => {
  res.render('cadastro', {
    erro: req.flash('erro'),
    sucesso: req.flash('sucesso')
  });
});


// ─────────────────────────────────────────────────────────────
// POST /cadastro — CREATE: insere usuário no banco
// ─────────────────────────────────────────────────────────────
router.post('/cadastro', async (req, res) => {
  const { nome, login, senha } = req.body;

  try {
    const usuarios = getUsuarios(); // pega a coleção 'usuarios'

    // LEITURA para checar duplicata
    // Com Mongoose: await Usuario.findOne({ login })
    // Com MongoDB:  await collection.findOne({ login })
    // A sintaxe é quase igual! A diferença é que aqui não há validação de schema
    const existe = await usuarios.findOne({ login });

    if (existe) {
      req.flash('erro', 'Login já cadastrado. Escolha outro.');
      return res.redirect('/cadastro');
    }

    // Criptografa a senha antes de salvar
    const hash = await bcrypt.hash(senha, 10);

    // INSERÇÃO no banco
    // Com Mongoose: await Usuario.create({ nome, login, senha: hash })
    // Com MongoDB:  await collection.insertOne({ ... })
    // insertOne() retorna um objeto com o _id gerado: { insertedId: ObjectId(...) }
    await usuarios.insertOne({
      nome,
      login,
      senha: hash,
      criadoEm: new Date() // MongoDB puro não tem timestamps automáticos — adicionamos manualmente
    });

    req.flash('sucesso', 'Cadastro realizado! Faça login.');
    res.redirect('/login');

  } catch (err) {
    req.flash('erro', 'Erro ao cadastrar: ' + err.message);
    res.redirect('/cadastro');
  }
});


// ─────────────────────────────────────────────────────────────
// GET /login — exibe o formulário
// ─────────────────────────────────────────────────────────────
router.get('/login', (req, res) => {
  res.render('login', { erro: req.flash('erro') });
});


// ─────────────────────────────────────────────────────────────
// POST /login — READ: busca usuário e autentica
// ─────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  const { login, senha } = req.body;

  try {
    const usuarios = getUsuarios();

    // Busca o usuário pelo login
    // Com Mongoose: await Usuario.findOne({ login })
    // Com MongoDB:  await collection.findOne({ login })
    const usuario = await usuarios.findOne({ login });

    if (!usuario) {
      req.flash('erro', 'Login ou senha incorretos.');
      return res.redirect('/login');
    }

    // Compara a senha digitada com o hash salvo
    const correto = await bcrypt.compare(senha, usuario.senha);

    if (!correto) {
      req.flash('erro', 'Login ou senha incorretos.');
      return res.redirect('/login');
    }

    // Salva os dados do usuário na sessão
    // usuario._id existe da mesma forma que no Mongoose
    req.session.usuario = {
      id:    usuario._id.toString(), // converte ObjectId para string
      nome:  usuario.nome,
      login: usuario.login
    };

    res.redirect('/carros');

  } catch (err) {
    req.flash('erro', 'Erro no login: ' + err.message);
    res.redirect('/login');
  }
});


// ─────────────────────────────────────────────────────────────
// GET /logout — encerra a sessão
// ─────────────────────────────────────────────────────────────
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});


module.exports = router;
